#!/bin/bash
./gradlew runDemo
